<!DOCTYPE html>   
<html lang="en">   
<head>   
<meta charset="utf-8">   
<title>Main Navigational Menu</title>   
<script src="js/jquery.js"></script>
    <script src="css/bootstrap.min.js"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet" media="screen">
</head>  
<body>  
<div class="container">  
<div class="row">  
<div class="span8">  
<ul class="nav nav-pills">  
<li class="active"><a href="#">Home</a></li>     
<li><a href="#" title="Click here to know tutorials">Tutorials</a></li>  
<li><a href="#">Practice Editor </a></li>   
<li><a href="#">Gallery</a></li>   
<li><a href="#">Contact</a></li>   
</ul>  
</div>  
</div>  
</div>  
</body>  
</html>  
